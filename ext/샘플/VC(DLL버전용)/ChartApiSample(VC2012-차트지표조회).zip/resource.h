//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// ChartAPISample.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_LOGINDLG                    103
#define IDR_MAINFRAME                   128
#define IDR_ChartAPISampleTYPE          129
#define IDD_INDEX11                     143
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_LOGIN                       1003
#define IDC_CANCEL                      1004
#define IDC_DATETIMEPICKER1             1011
#define IDC_MARKET                      1019
#define IDC_CODE                        1020
#define IDC_QUERY                       1021
#define IDC_LIST                        1022
#define IDC_PERIOD                      1024
#define IDC_CODE2                       1025
#define IDC_COUNT                       1025
#define IDC_EDIT_EXCEL_FILE             1026
#define IDC_COMBO                       1027
#define IDC_CHECK1                      1028
#define IDC_CHECK_AUTO_ORDER            1028
#define IDC_CHECK_REAL                  1028
#define IDC_CHECK_EXCEL                 1029
#define IDC_ST_MSG                      1030
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_                             32773
#define ID_CHARTMNG                     32774
#define ID_CHARTREP                     32775
#define ID_CHARTLIB                     32776
#define ID_32777                        32777
#define ID_LOGIN                        32778
#define ID_Menu                         32779
#define ID_INDEX                        32780
#define ID_CHARTINDEX                   32781
#define ID_INDICATOR_STATUS             59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
